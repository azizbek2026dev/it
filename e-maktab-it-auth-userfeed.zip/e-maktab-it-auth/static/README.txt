Tailwind CSS CDN ishlatiladi.
